# soilbgc-farm
a group of different implementations for soil biogeochemical modeling.
CENT_ECACNP: a modified implementation of ECA-CNP, which removed some inconsistencies in phosphorus dynamics and nitrogen dynamics
