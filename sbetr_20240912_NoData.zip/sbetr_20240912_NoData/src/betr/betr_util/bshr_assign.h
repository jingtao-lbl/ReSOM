#define FPMAX(a,b)  a=max(b,0._r8)
